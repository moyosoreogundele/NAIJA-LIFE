renderHeader("");
document.getElementById("site-footer") && renderFooter();

function setFieldError(fieldId, show) {
  document.getElementById(fieldId)?.classList.toggle("error", show);
}

/* ---- Login ---- */
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  document.getElementById("pwToggle")?.addEventListener("click", () => togglePw("password", "pwToggle"));
  loginForm.addEventListener("submit", e => {
    e.preventDefault();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    let valid = true;
    if (!/^\S+@\S+\.\S+$/.test(email)) { setFieldError("emailField", true); valid = false; } else setFieldError("emailField", false);
    if (!valid) return;

    const result = Auth.login(email, password);
    if (!result.ok) {
      setFieldError("passField", true);
      toast(result.error, "error");
      return;
    }
    setFieldError("passField", false);
    toast("Login successful", "success");
    setTimeout(() => location.href = "profile.html", 500);
  });
}

/* ---- Register ---- */
const registerForm = document.getElementById("registerForm");
if (registerForm) {
  document.getElementById("regPwToggle")?.addEventListener("click", () => togglePw("regPassword", "regPwToggle"));
  registerForm.addEventListener("submit", e => {
    e.preventDefault();
    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("regEmail").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const password = document.getElementById("regPassword").value;
    const confirm = document.getElementById("confirmPassword").value;
    let valid = true;

    setFieldError("nameField", !name); if (!name) valid = false;
    const emailOk = /^\S+@\S+\.\S+$/.test(email);
    setFieldError("regEmailField", !emailOk); if (!emailOk) valid = false;
    const passOk = password.length >= 8;
    setFieldError("regPassField", !passOk); if (!passOk) valid = false;
    const matchOk = password === confirm && confirm.length > 0;
    setFieldError("confirmField", !matchOk); if (!matchOk) valid = false;

    if (!valid) return;

    const result = Auth.register({ name, email, password, phone });
    if (!result.ok) { toast(result.error, "error"); return; }
    toast("Account created — welcome to NaijaLife!", "success");
    setTimeout(() => location.href = "profile.html", 500);
  });
}

function togglePw(inputId, btnId) {
  const input = document.getElementById(inputId);
  const btn = document.getElementById(btnId);
  const isPw = input.type === "password";
  input.type = isPw ? "text" : "password";
  btn.innerHTML = `<i data-lucide="${isPw ? "eye-off" : "eye"}"></i>`;
  mountIcons();
}
