# NaijaLife Fashion

**Your Style. Your Nigeria.**

A frontend-only Nigerian fashion marketplace demo, built with plain HTML, CSS and vanilla JavaScript — no frameworks, no build step, no backend.

## What's included

- Homepage, full shop with filters/sort, product detail pages, cart, wishlist
- Login / register (demo, localStorage-based auth)
- Multi-step checkout with a clearly-labelled **Demo Payment** flow
- Order history with a visual status timeline
- Designer directory and individual designer storefronts
- Global search, product reviews, category pages (Men, Women, Kids, Shoes, Bags, Accessories, Native Wear, Streetwear, Agbada, Ankara, Aso-Ebi, Sale)
- Fully responsive, dark luxury theme with gold accents, down to 320px

**Not included in this build:** the seller and admin back-office dashboards and PWA install support described in the original brief were left out to keep the shipped experience fully polished rather than spreading effort across 40+ pages. The storefront (browse → cart → checkout → orders → account) is complete and working end to end.

## How to run it

Just open `index.html` in any modern browser — double-click the file, or drag it into a browser window. Every page links correctly relative to the others.

**Optional — run with a local server** (only needed if you want to add PWA/service-worker support later):
- VS Code: install the "Live Server" extension, right-click `index.html` → "Open with Live Server"
- Python: `python3 -m http.server 8000` from this folder, then visit `http://localhost:8000`

## Demo accounts

| Role | Email | Password |
|---|---|---|
| Customer | customer@naijalife.demo | Customer123 |
| Seller | seller@naijalife.demo | Seller123 |
| Admin | admin@naijalife.demo | Admin123 |

You can also register a new account — it's stored in your browser's localStorage.

## How localStorage is used

All "backend" state — accounts, sessions, cart, wishlist, orders, addresses, reviews — lives in your browser's `localStorage`. Nothing is sent to a server. Clearing your browser storage resets the app. This is intentional: it's a frontend demo, not a production system.

**For production, you would need:** a real backend for authentication (hashed passwords, sessions/JWT), a payment gateway integration handled server-side (Paystack/Flutterwave secret keys must never live in browser JavaScript), a database for orders/inventory, and server-side validation of everything currently validated only in the browser.

## Replacing demo images

Product, designer and hero images currently load from `picsum.photos` placeholder URLs generated in `js/data.js` via the `img()` helper. To use real photography:
1. Drop files into `assets/images/products/`, `assets/images/designers/`, etc.
2. Update the relevant `images` / `logo` / `cover` fields in `js/data.js` to point at those local paths instead.

## File structure

```
index.html, shop.html, product.html, login.html, register.html,
cart.html, checkout.html, wishlist.html, orders.html, profile.html,
designers.html, designer.html, search.html, 404.html
pages/            → category pages (men, women, kids, shoes, bags, ...)
css/style.css      → design system (tokens, layout, components)
css/auth.css        → auth page tweaks
js/data.js          → demo products, designers, Nigerian states
js/app.js           → cart, wishlist, auth, toasts, modals, header/footer
js/filters.js, product.js, cart.js, wishlist.js, checkout.js,
js/orders.js, profile.js, designers.js, search.js, category.js, auth.js
```

## Icons

Icons are rendered with [Lucide](https://lucide.dev) loaded via CDN (`unpkg.com/lucide`).
